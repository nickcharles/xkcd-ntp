xkcd-ntp
========

An xkcd new tab page for Google Chrome, an extension of romance,sarcasm, math, and language.

Displays the most recent xkcd comic on the new tab page instead of the original content provided by Chrome.

TODO:
Add browsing feature to go view all comics, just like on actual website.
Add expanding section that shows alt text below the comic.
Center display.
Edit icons to add transparency.


========


All credit for the comic material goes to the author and illustrator at http://xkcd.com/. No copyright infringment is intended with this extension.

DISCLAIMER: I have been told that this comic occasionally contains strong language (which may be unsuitable for children), unusual humor (which may be unsuitable for adults), and advanced mathematics (which may be unsuitable for liberal-arts majors). Therefore, the developer (me) cannot be held responsible for the content of the comic displayed by this extension. Comsumption of the comic material presented by this extension is solely the responsibility of the user.